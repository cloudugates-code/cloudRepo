package com.example.batch;

import com.example.batch.entity.Order;
import com.example.batch.model.ZipResult;
import com.example.batch.processor.OrderProcessor;
import com.example.batch.reader.OrderItemReader;
import com.example.batch.repository.OrderRepository;
import com.example.batch.tasklet.MoveZipTasklet;
import com.example.batch.tasklet.UpdateOrderStatusTasklet;
import com.example.batch.writer.ZipWriter;
import jakarta.persistence.EntityManagerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.tasklet.TaskletStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.builder.JpaPagingItemReaderBuilder;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

    @Value("${batch.chunk.size:10}")
    private int chunkSize;

    @Bean
    public JpaPagingItemReader<Order> orderReader(EntityManagerFactory emf) {
        return new JpaPagingItemReaderBuilder<Order>()
                .name("orderReader")
                .entityManagerFactory(emf)
                .queryString("SELECT o FROM Order o WHERE o.status = 'RECEIVED'")
                .pageSize(chunkSize)
                .build();
    }

    @Bean
    public ItemProcessor<Order, ZipResult> orderProcessor() {
        return new OrderProcessor();
    }

    @Bean
    public ItemWriter<ZipResult> zipWriter() {
        return new ZipWriter();
    }

    @Bean
    public Step processZipStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
                               JpaPagingItemReader<Order> reader, ItemProcessor<Order, ZipResult> processor,
                               ItemWriter<ZipResult> writer) {
        return new StepBuilder("processZipStep", jobRepository)
                .<Order, ZipResult>chunk(chunkSize, transactionManager)
                .reader(reader)
                .processor(processor)
                .writer(writer)
                .build();
    }

    @Bean
    public TaskletStep moveZipStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
                                   MoveZipTasklet moveZipTasklet) {
        return new StepBuilder("moveZipStep", jobRepository)
                .tasklet(moveZipTasklet, transactionManager)
                .build();
    }

    @Bean
    public TaskletStep updateOrderStatusStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
                                             UpdateOrderStatusTasklet updateOrderStatusTasklet) {
        return new StepBuilder("updateOrderStatusStep", jobRepository)
                .tasklet(updateOrderStatusTasklet, transactionManager)
                .build();
    }

    @Bean
    public Job zipProcessingJob(JobRepository jobRepository, Step processZipStep, Step moveZipStep, Step updateOrderStatusStep) {
        return new JobBuilder("zipProcessingJob", jobRepository)
                .start(processZipStep)
                .next(moveZipStep)
                .next(updateOrderStatusStep)
                .build();
    }
}