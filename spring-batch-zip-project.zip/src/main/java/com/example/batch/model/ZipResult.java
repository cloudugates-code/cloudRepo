package com.example.batch.model;

public class ZipResult {
    private String zipFileAPath;
    private String zipFileBPath;
    private String orderId;

    public ZipResult(String orderId, String zipFileAPath, String zipFileBPath) {
        this.orderId = orderId;
        this.zipFileAPath = zipFileAPath;
        this.zipFileBPath = zipFileBPath;
    }

    // Getters and setters
    public String getZipFileAPath() {
        return zipFileAPath;
    }

    public void setZipFileAPath(String zipFileAPath) {
        this.zipFileAPath = zipFileAPath;
    }

    public String getZipFileBPath() {
        return zipFileBPath;
    }

    public void setZipFileBPath(String zipFileBPath) {
        this.zipFileBPath = zipFileBPath;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}